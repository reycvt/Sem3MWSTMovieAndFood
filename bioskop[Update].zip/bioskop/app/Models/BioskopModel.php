<?php

namespace App\Models;

use CodeIgniter\Model;

class BioskopModel extends Model
{
    protected $table = 'tb_bioskop';
    protected $primaryKey = 'id';

    protected $allowedFields = [
        'nama',
        'status',
        'alamat',
    ];
    protected $validationRules = [
        'nama' => 'required',
        'status' => 'required',
        'alamat' => 'required',
    ];
    protected $validationMessage = [
        'nama' => ['required' => 'Nama tidak boleh kosong'],
        'status' => ['required' => 'Status tidak boleh kosong'],
        'alamat' => ['required' => 'Alamat tidak boleh kosong'],
    ];
}