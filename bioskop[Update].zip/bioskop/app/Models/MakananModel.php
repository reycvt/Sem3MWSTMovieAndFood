<?php

namespace App\Models;

use CodeIgniter\Model;

class MakananModel extends Model
{
    protected $table = 'tb_makanan';
    protected $primaryKey = 'id';

    protected $allowedFields = [
        'nama',
        'status',
        'harga',
    ];
    protected $validationRules = [
        'nama' => 'required',
        'status' => 'required',
        'harga' => 'required',
    ];
    protected $validationMessage = [
        'nama' => ['required' => 'Nama tidak boleh kosong'],
        'status' => ['required' => 'Status tidak boleh kosong'],
        'harga' => ['required' => 'harga tidak boleh kosong'],
    ];
}