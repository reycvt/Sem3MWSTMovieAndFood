<?php

namespace App\Models;

use CodeIgniter\Model;

class MoviesModel extends Model
{
    protected $table = 'tb_movies';
    protected $primaryKey = 'id';

    protected $allowedFields = [
        'judul',
        'genre',
        'date',
        'durasi',
    ];
    protected $validationRules = [
        'judul' => 'required',
        'genre' => 'required',
        'date' => 'required',
        'durasi' => 'required',
    ];
    protected $validationMessage = [
        'judul' => ['required' => 'judul tidak boleh kosong'],
        'genre' => ['required' => 'genre tidak boleh kosong'],
        'date' => ['required' => 'date tidak boleh kosong'],
        'durasi' => ['required' => 'durasi tidak boleh kosong'],
    ];
}