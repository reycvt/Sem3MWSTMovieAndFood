<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use CodeIgniter\RESTful\ResourceController;

class Bioskop extends ResourceController
{
    use ResponseTrait;

    protected $modelName = 'App\Models\BioskopModel';
    protected $format = 'json';

    public function index()
    {
        $data = $this->model->orderBy('id', 'asc')->findAll();
        $response = [
            'error' => false,
            'message' =>"Data Terhubung",
            'data' => $data
        ];
        return $this->respond($response);
    }
    public function create()
    {
        $data = $this->request->getPost();

        if (empty($data)) {
            return $this->fail('Data yang dimasukkan kosong');
        }

        $save = $this->model->save($data);

        if (!$save) {
            return $this->fail($this->model->errors());
        }
        $response = [
            'status' => 201,
            'error' => null,
            'message' => [
                'success' => 'Data berhasil ditambahkan',
            ],
        ];

        return $this->respondCreated($response);
    }
    public function show($id = null)
    {
        $data = $this->model->where('id', $id)->find();
        if ($data) {
            return $this->respond($data, 200);
        } else {
            return $this->failNotFound('Data tidak ditemukan');
        }
    }

    public function update($id = null)
    {
        $data = $this->request->getRawInput();
        $data['id'] = $id;

        $check_data = $this->model->where('id', $id)->find();

        if (!$check_data) {
            return $this->failNotFound('Data tidak ditemukan');
        }

        $save = $this->model->save($data);

        if (!$save) {
            return $this->fail($this->model->errors());
        }

        $response = [
            'status' => 200,
            'error' => false,
            'message' => 'Data berhasil diubah'
        ];

        return $this->respond($response);
    }
    public function delete($id = null)
    {
        $check_data = $this->model->where('id', $id)->delete($id);

        if ($check_data) {
            $this->model->delete($id);

            $response = [
                'status' => 200,
                'error' => null,
                'message' => [
                    'success' => 'Data berhasil dihapus',
                ],
            ];

            return $this->respondDeleted($response);
        }

        return $this->failNotFound('Data tidak ditemukan');
    }
}